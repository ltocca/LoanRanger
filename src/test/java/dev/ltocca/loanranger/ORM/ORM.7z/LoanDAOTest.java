/*

// File: LoanDAOIntegrationTest.java
package dev.ltocca.loanranger.ORM;

import dev.ltocca.loanranger.domainModel.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

class LoanDAOTest extends OrmIntegrationTestBase {

    private Library testLibrary;
    private Book testBook;
    private BookCopy testBookCopy;
    private Member testMember;

    @BeforeEach
    void setUp() throws Exception {
        executeSchemaScript();
        testLibrary = createTestLibrary();
        testBook = createTestBook();
        testBookCopy = createTestBookCopy(testBook, testLibrary);
        testMember = createTestMember();
    }

    @Test
    void createLoan_WithLoanObject_ShouldCreateLoanSuccessfully() {
        // Arrange
        Loan loan = new Loan(testBookCopy, testMember, LocalDate.now());

        // Act
        Loan createdLoan = loanDAO.createLoan(loan);

        // Assert
        assertThat(createdLoan).isNotNull();
        assertThat(createdLoan.getId()).isNotNull();
        assertThat(createdLoan.getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
        assertThat(createdLoan.getMember().getId()).isEqualTo(testMember.getId());
        assertThat(createdLoan.getLoanDate()).isEqualTo(LocalDate.now());
    }

    @Test
    void createLoan_WithBookCopyAndMember_ShouldCreateLoanSuccessfully() {
        // Act
        Loan createdLoan = loanDAO.createLoan(testBookCopy, testMember);

        // Assert
        assertThat(createdLoan).isNotNull();
        assertThat(createdLoan.getId()).isNotNull();
        assertThat(createdLoan.getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
        assertThat(createdLoan.getMember().getId()).isEqualTo(testMember.getId());
        assertThat(createdLoan.getLoanDate()).isEqualTo(LocalDate.now());
    }

    @Test
    void getLoanById_ShouldReturnLoanWhenExists() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);

        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanById(loan.getId());

        // Assert
        assertThat(foundLoan).isPresent();
        assertThat(foundLoan.get().getId()).isEqualTo(loan.getId());
        assertThat(foundLoan.get().getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
    }

    @Test
    void getLoanById_ShouldReturnEmptyWhenLoanNotFound() {
        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanById(999L);

        // Assert
        assertThat(foundLoan).isEmpty();
    }

    @Test
    void getLoanByBookCopy_ShouldReturnLoanWhenExists() {
        // Arrange
        createTestLoan(testBookCopy, testMember);

        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanByBookCopy(testBookCopy);

        // Assert
        assertThat(foundLoan).isPresent();
        assertThat(foundLoan.get().getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
    }

    @Test
    void getLoanByBookCopyId_ShouldReturnLoanWhenExists() {
        // Arrange
        createTestLoan(testBookCopy, testMember);

        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanByBookCopyId(testBookCopy.getCopyId());

        // Assert
        assertThat(foundLoan).isPresent();
        assertThat(foundLoan.get().getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
    }

    @Test
    void updateLoan_ShouldUpdateLoanInformation() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        loan.setReturnDate(LocalDate.now());

        // Act
        loanDAO.updateLoan(loan);

        // Assert
        Optional<Loan> updatedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(updatedLoan).isPresent();
        assertThat(updatedLoan.get().getReturnDate()).isEqualTo(LocalDate.now());
    }

    @Test
    void updateDueDate_WithDays_ShouldExtendDueDate() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        LocalDate originalDueDate = loan.getDueDate();

        // Act
        loanDAO.updateDueDate(loan.getId(), 15);

        // Assert
        Optional<Loan> updatedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(updatedLoan).isPresent();
        assertThat(updatedLoan.get().getDueDate()).isEqualTo(originalDueDate.plusDays(15));
    }

    @Test
    void updateDueDate_WithDate_ShouldUpdateDueDate() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        LocalDate newDueDate = LocalDate.now().plusDays(60);

        // Act
        loanDAO.updateDueDate(loan.getId(), newDueDate);

        // Assert
        Optional<Loan> updatedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(updatedLoan).isPresent();
        assertThat(updatedLoan.get().getDueDate()).isEqualTo(newDueDate);
    }

    @Test
    void findLoansByMember_ShouldReturnAllMemberLoans() {
        // Arrange
        createTestLoan(testBookCopy, testMember);

        // Create another loan for different member
        Member member2 = new Member("member2", "member2@test.com", "password");
        userDAO.createUser(member2);
        Loan loan2 = createTestLoan(testBookCopy, (Member) member2);

        // Act
        List<Loan> memberLoans = loanDAO.findLoansByMember(testMember);

        // Assert
        assertThat(memberLoans).hasSize(1);
        assertThat(memberLoans.get(0).getMember().getId()).isEqualTo(testMember.getId());
    }

    @Test
    void findActiveLoansByMember_ShouldReturnOnlyActiveLoans() {
        // Arrange
        Loan activeLoan = createTestLoan(testBookCopy, testMember);

        // Create returned loan
        BookCopy copy2 = createTestBookCopy(testBook, testLibrary);
        Loan returnedLoan = createTestLoan(copy2, testMember);
        returnedLoan.setReturnDate(LocalDate.now());
        loanDAO.updateLoan(returnedLoan);

        // Act
        List<Loan> activeLoans = loanDAO.findActiveLoansByMember(testMember);

        // Assert
        assertThat(activeLoans).hasSize(1);
        assertThat(activeLoans.get(0).getId()).isEqualTo(activeLoan.getId());
        assertThat(activeLoans.get(0).getReturnDate()).isNull();
    }

    @Test
    void findOverdueLoans_ShouldReturnOnlyOverdueLoans() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);

        // Manually set due date to past
        loanDAO.updateDueDate(loan.getId(), LocalDate.now().minusDays(1));

        // Act
        List<Loan> overdueLoans = loanDAO.findOverdueLoans();

        // Assert
        assertThat(overdueLoans).hasSize(1);
        assertThat(overdueLoans.get(0).getId()).isEqualTo(loan.getId());
    }

    @Test
    void deleteLoan_ShouldRemoveLoanFromDatabase() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);

        // Act
        loanDAO.deleteLoan(loan.getId());

        // Assert
        Optional<Loan> deletedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(deletedLoan).isEmpty();
    }
}
// File: LoanDAOTest.java
*/
/*
package dev.ltocca.loanranger.ORM;

import dev.ltocca.loanranger.domainModel.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.annotation.Commit;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

class LoanDAOTest extends OrmIntegrationTestBase {

    private Library testLibrary;
    private Book testBook;
    private BookCopy testBookCopy;
    private BookCopy testBookCopy2; // Add second copy for tests that need multiple loans
    private Member testMember;
    private Member testMember2;

    @BeforeEach
    void setUp() throws Exception {
        executeSchemaScript();
        testLibrary = createTestLibrary();
        testBook = createTestBook();
        testBookCopy = createTestBookCopy(testBook, testLibrary);
        testBookCopy2 = createTestBookCopy(testBook, testLibrary); // Create second copy
        testMember = createTestMember();

        // Create second member
        testMember2 = new Member();
        testMember2.setUsername("member2");
        testMember2.setName("Member Two");
        testMember2.setEmail("member2@test.com");
        testMember2.setPassword("password");
        testMember2.setRole(UserRole.MEMBER);
        userDAO.createUser(testMember2);
    }

    @Test
    void createLoan_WithLoanObject_ShouldCreateLoanSuccessfully() {
        // Arrange
        Loan loan = new Loan(testBookCopy, testMember, LocalDate.now());

        // Act
        Loan createdLoan = loanDAO.createLoan(loan);

        // Assert
        assertThat(createdLoan).isNotNull();
        assertThat(createdLoan.getId()).isNotNull();
        assertThat(createdLoan.getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
        assertThat(createdLoan.getMember().getId()).isEqualTo(testMember.getId());
        assertThat(createdLoan.getLoanDate()).isEqualTo(LocalDate.now());
    }

    @Test
    void createLoan_WithBookCopyAndMember_ShouldCreateLoanSuccessfully() {
        // Act
        Loan createdLoan = loanDAO.createLoan(testBookCopy, testMember);

        // Assert
        assertThat(createdLoan).isNotNull();
        assertThat(createdLoan.getId()).isNotNull();
        assertThat(createdLoan.getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
        assertThat(createdLoan.getMember().getId()).isEqualTo(testMember.getId());
        assertThat(createdLoan.getLoanDate()).isEqualTo(LocalDate.now());
    }

    @Test
    void getLoanById_ShouldReturnLoanWhenExists() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull(); // Verify ID is set

        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanById(loan.getId());

        // Assert
        assertThat(foundLoan).isPresent();
        assertThat(foundLoan.get().getId()).isEqualTo(loan.getId());
        assertThat(foundLoan.get().getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
    }

    @Test
    void getLoanById_ShouldReturnEmptyWhenLoanNotFound() {
        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanById(999L);

        // Assert
        assertThat(foundLoan).isEmpty();
    }

    @Test
    void getLoanByBookCopy_ShouldReturnLoanWhenExists() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();

        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanByBookCopy(testBookCopy);

        // Assert
        assertThat(foundLoan).isPresent();
        assertThat(foundLoan.get().getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
    }

    @Test
    void getLoanByBookCopyId_ShouldReturnLoanWhenExists() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();

        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanByBookCopyId(testBookCopy.getCopyId());

        // Assert
        assertThat(foundLoan).isPresent();
        assertThat(foundLoan.get().getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
    }

    @Test
    void updateLoan_ShouldUpdateLoanInformation() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();

        loan.setReturnDate(LocalDate.now());

        // Act
        loanDAO.updateLoan(loan);

        // Assert
        Optional<Loan> updatedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(updatedLoan).isPresent();
        assertThat(updatedLoan.get().getReturnDate()).isEqualTo(LocalDate.now());
    }

    @Test
    void updateDueDate_WithDays_ShouldExtendDueDate() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();

        LocalDate originalDueDate = loan.getDueDate();

        // Act
        loanDAO.updateDueDate(loan.getId(), 15);

        // Assert
        Optional<Loan> updatedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(updatedLoan).isPresent();
        assertThat(updatedLoan.get().getDueDate()).isEqualTo(originalDueDate.plusDays(15));
    }

    @Test
    void updateDueDate_WithDate_ShouldUpdateDueDate() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();

        LocalDate newDueDate = LocalDate.now().plusDays(60);

        // Act
        loanDAO.updateDueDate(loan.getId(), newDueDate);

        // Assert
        Optional<Loan> updatedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(updatedLoan).isPresent();
        assertThat(updatedLoan.get().getDueDate()).isEqualTo(newDueDate);
    }

    @Test
    @Commit
    void findLoansByMember_ShouldReturnAllMemberLoans() {
        // Arrange
        Loan loan1 = createTestLoan(testBookCopy, testMember);
        assertThat(loan1.getId()).isNotNull();

        // Use second copy for second loan to avoid unique constraint
        Loan loan2 = createTestLoan(testBookCopy2, testMember);
        assertThat(loan2.getId()).isNotNull();

        // Act
        List<Loan> memberLoans = loanDAO.findLoansByMember(testMember);

        // Assert
        assertThat(memberLoans).hasSize(2);
        assertThat(memberLoans).allMatch(loan -> loan.getMember().getId().equals(testMember.getId()));
    }

    @Test
    void findActiveLoansByMember_ShouldReturnOnlyActiveLoans() {
        // Arrange
        Loan activeLoan = createTestLoan(testBookCopy, testMember);
        assertThat(activeLoan.getId()).isNotNull();

        // Create returned loan using second copy
        Loan returnedLoan = createTestLoan(testBookCopy2, testMember);
        assertThat(returnedLoan.getId()).isNotNull();
        returnedLoan.setReturnDate(LocalDate.now());
        loanDAO.updateLoan(returnedLoan);

        // Act
        List<Loan> activeLoans = loanDAO.findActiveLoansByMember(testMember);

        // Assert
        assertThat(activeLoans).hasSize(1);
        assertThat(activeLoans.get(0).getId()).isEqualTo(activeLoan.getId());
        assertThat(activeLoans.get(0).getReturnDate()).isNull();
    }

    @Test
    void findOverdueLoans_ShouldReturnOnlyOverdueLoans() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();

        // Manually set due date to past
        LocalDate pastDueDate = LocalDate.now().minusDays(1);
        loanDAO.updateDueDate(loan.getId(), pastDueDate);

        // Act
        List<Loan> overdueLoans = loanDAO.findOverdueLoans();

        // Assert
        assertThat(overdueLoans).hasSize(1);
        assertThat(overdueLoans.get(0).getId()).isEqualTo(loan.getId());
        assertThat(overdueLoans.get(0).getDueDate()).isEqualTo(pastDueDate);
    }

    @Test
    void deleteLoan_ShouldRemoveLoanFromDatabase() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();

        // Act
        loanDAO.deleteLoan(loan.getId());

        // Assert
        Optional<Loan> deletedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(deletedLoan).isEmpty();
    }

    @Test
    void findActiveLoansByLibrary_ShouldReturnActiveLoansForLibrary() {
        // Arrange
        Loan activeLoan = createTestLoan(testBookCopy, testMember);
        assertThat(activeLoan.getId()).isNotNull();

        // Act
        List<Loan> activeLoans = loanDAO.findActiveLoansByLibrary(testLibrary);

        // Assert
        assertThat(activeLoans).hasSize(1);
        assertThat(activeLoans.get(0).getBookCopy().getLibrary().getId()).isEqualTo(testLibrary.getId());
    }

    @Test
    void findMemberOverdueLoans_ShouldReturnOverdueLoansForMember() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();

        // Set due date to past
        LocalDate pastDueDate = LocalDate.now().minusDays(1);
        loanDAO.updateDueDate(loan.getId(), pastDueDate);

        // Act
        List<Loan> overdueLoans = loanDAO.findMemberOverdueLoans(testMember.getId());

        // Assert
        assertThat(overdueLoans).hasSize(1);
        assertThat(overdueLoans.get(0).getMember().getId()).isEqualTo(testMember.getId());
        assertThat(overdueLoans.get(0).getDueDate()).isEqualTo(pastDueDate);
    }
*//*

//}*/


// File: LoanDAOTest.java
package dev.ltocca.loanranger.ORM;

import dev.ltocca.loanranger.domainModel.*;
import dev.ltocca.loanranger.domainModel.State.LoanedState;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

// Inherits: @JdbcTest, @Testcontainers, @Import, @Transactional, Container, Properties, Common DAOs, Constants, Helpers
class LoanDAOTest extends OrmIntegrationTestBase {

    private Library testLibrary;
    private Book testBook;
    private BookCopy testBookCopy;
    private BookCopy testBookCopy2; // Add second copy for tests that need multiple loans
    private Member testMember;
    private Member testMember2;

    @BeforeEach
    void setUp() throws Exception {
        executeSchemaScript();
        testLibrary = createTestLibrary();
        testBook = createTestBook();
        testBookCopy = createTestBookCopy(testBook, testLibrary);
        testBookCopy2 = createTestBookCopy(testBook, testLibrary); // Create second copy
        testMember = createTestMember();
        // Create second member
        testMember2 = new Member();
        testMember2.setUsername("member2");
        testMember2.setName("Member Two");
        testMember2.setEmail("member2@test.com");
        testMember2.setPassword("password");
        testMember2.setRole(UserRole.MEMBER);
        userDAO.createUser(testMember2);
    }

    @Test
    void createLoan_WithLoanObject_ShouldCreateLoanSuccessfully() {
        // Arrange
        Loan loan = new Loan(testBookCopy, testMember, LocalDate.now());
        // Act
        Loan createdLoan = loanDAO.createLoan(loan);
        // Assert
        assertThat(createdLoan).isNotNull();
        assertThat(createdLoan.getId()).isNotNull();
        assertThat(createdLoan.getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
        assertThat(createdLoan.getMember().getId()).isEqualTo(testMember.getId());
        assertThat(createdLoan.getLoanDate()).isEqualTo(LocalDate.now());
    }

    @Test
    void createLoan_WithBookCopyAndMember_ShouldCreateLoanSuccessfully() {
        // Act
        Loan createdLoan = loanDAO.createLoan(testBookCopy, testMember);
        // Assert
        assertThat(createdLoan).isNotNull();
        assertThat(createdLoan.getId()).isNotNull();
        assertThat(createdLoan.getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
        assertThat(createdLoan.getMember().getId()).isEqualTo(testMember.getId());
        assertThat(createdLoan.getLoanDate()).isEqualTo(LocalDate.now());
    }

    @Test
    void getLoanById_ShouldReturnLoanWhenExists() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull(); // Verify ID is set
        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanById(loan.getId());
        // Assert
        assertThat(foundLoan).isPresent();
        assertThat(foundLoan.get().getId()).isEqualTo(loan.getId());
        assertThat(foundLoan.get().getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
    }

    @Test
    void getLoanById_ShouldReturnEmptyWhenLoanNotFound() {
        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanById(999L);
        // Assert
        assertThat(foundLoan).isEmpty();
    }

    @Test
    void getLoanByBookCopy_ShouldReturnLoanWhenExists() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();
        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanByBookCopy(testBookCopy);
        // Assert
        assertThat(foundLoan).isPresent();
        assertThat(foundLoan.get().getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
    }

    @Test
    void getLoanByBookCopyId_ShouldReturnLoanWhenExists() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();
        // Act
        Optional<Loan> foundLoan = loanDAO.getLoanByBookCopyId(testBookCopy.getCopyId());
        // Assert
        assertThat(foundLoan).isPresent();
        assertThat(foundLoan.get().getBookCopy().getCopyId()).isEqualTo(testBookCopy.getCopyId());
    }

    @Test
    void updateLoan_ShouldUpdateLoanInformation() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();
        loan.setReturnDate(LocalDate.now());
        // Act
        loanDAO.updateLoan(loan);
        // Assert
        Optional<Loan> updatedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(updatedLoan).isPresent();
        assertThat(updatedLoan.get().getReturnDate()).isEqualTo(LocalDate.now());
    }

    @Test
    void updateDueDate_WithDays_ShouldExtendDueDate() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();
        LocalDate originalDueDate = loan.getDueDate();
        // Act
        loanDAO.updateDueDate(loan.getId(), 15);
        // Assert
        Optional<Loan> updatedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(updatedLoan).isPresent();
        assertThat(updatedLoan.get().getDueDate()).isEqualTo(originalDueDate.plusDays(15));
    }

    @Test
    void updateDueDate_WithDate_ShouldUpdateDueDate() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();
        LocalDate newDueDate = LocalDate.now().plusDays(60);
        // Act
        loanDAO.updateDueDate(loan.getId(), newDueDate);
        // Assert
        Optional<Loan> updatedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(updatedLoan).isPresent();
        assertThat(updatedLoan.get().getDueDate()).isEqualTo(newDueDate);
    }

    @Test
    void findLoansByMember_ShouldReturnAllMemberLoans() {
        // Arrange
        createTestLoan(testBookCopy, testMember);
        // Create another loan for different member
        Loan loan2 = createTestLoan(testBookCopy2, testMember2);
        // Act
        List<Loan> memberLoans = loanDAO.findLoansByMember(testMember);
        // Assert
        assertThat(memberLoans).hasSize(1);
        assertThat(memberLoans.get(0).getMember().getId()).isEqualTo(testMember.getId());
    }

    @Test
    void findActiveLoansByMember_ShouldReturnOnlyActiveLoans() {
        // Arrange
        Loan activeLoan = createTestLoan(testBookCopy, testMember);
        assertThat(activeLoan.getId()).isNotNull();
        // Create returned loan using second copy
        Loan returnedLoan = createTestLoan(testBookCopy2, testMember);
        assertThat(returnedLoan.getId()).isNotNull();
        returnedLoan.setReturnDate(LocalDate.now());
        loanDAO.updateLoan(returnedLoan);
        // Act
        List<Loan> activeLoans = loanDAO.findActiveLoansByMember(testMember);
        // Assert
        assertThat(activeLoans).hasSize(1);
        assertThat(activeLoans.get(0).getId()).isEqualTo(activeLoan.getId());
        assertThat(activeLoans.get(0).getReturnDate()).isNull();
    }

    @Test
    void findOverdueLoans_ShouldReturnOnlyOverdueLoans() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();
        // Manually set due date to past
        LocalDate pastDueDate = LocalDate.now().minusDays(1);
        loanDAO.updateDueDate(loan.getId(), pastDueDate);
        // Act
        List<Loan> overdueLoans = loanDAO.findOverdueLoans();
        // Assert
        assertThat(overdueLoans).hasSize(1);
        assertThat(overdueLoans.get(0).getId()).isEqualTo(loan.getId());
        assertThat(overdueLoans.get(0).getDueDate()).isEqualTo(pastDueDate);
    }

    @Test
    void findActiveLoansByLibrary_ShouldReturnActiveLoansForLibrary() {
        // Arrange
        Loan activeLoan = createTestLoan(testBookCopy, testMember);
        assertThat(activeLoan.getId()).isNotNull();
        // Act
        List<Loan> activeLoans = loanDAO.findActiveLoansByLibrary(testLibrary);
        // Assert
        assertThat(activeLoans).hasSize(1);
        assertThat(activeLoans.get(0).getBookCopy().getLibrary().getId()).isEqualTo(testLibrary.getId());
    }

    @Test
    void findMemberOverdueLoans_ShouldReturnOverdueLoansForMember() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        assertThat(loan.getId()).isNotNull();
        // Set due date to past
        LocalDate pastDueDate = LocalDate.now().minusDays(1);
        loanDAO.updateDueDate(loan.getId(), pastDueDate);
        // Act
        List<Loan> overdueLoans = loanDAO.findMemberOverdueLoans(testMember.getId());
        // Assert
        assertThat(overdueLoans).hasSize(1);
        assertThat(overdueLoans.get(0).getId()).isEqualTo(loan.getId());
        assertThat(overdueLoans.get(0).getMember().getId()).isEqualTo(testMember.getId());
        assertThat(overdueLoans.get(0).getDueDate()).isEqualTo(pastDueDate);
    }

    @Test
    void deleteLoan_ShouldRemoveLoanFromDatabase() {
        // Arrange
        Loan loan = createTestLoan(testBookCopy, testMember);
        // Act
        loanDAO.deleteLoan(loan.getId());
        // Assert
        Optional<Loan> deletedLoan = loanDAO.getLoanById(loan.getId());
        assertThat(deletedLoan).isEmpty();
    }
}