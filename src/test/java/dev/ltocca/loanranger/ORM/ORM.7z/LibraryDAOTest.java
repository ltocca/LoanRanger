package dev.ltocca.loanranger.ORM;

import dev.ltocca.loanranger.BaseIntegrationTest;
import dev.ltocca.loanranger.domainModel.Library;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;

@Import(LibraryDAO.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class LibraryDAOTest extends BaseIntegrationTest {

    @Autowired
    private LibraryDAO libraryDAO;

    @Test
    void createLibrary_shouldInsertAndReturnLibraryWithGeneratedId() {
        // Given
        Library library = new Library("Central Library", "123 Main St", "555-1234", "central@library.com");

        // When
        Library created = libraryDAO.createLibrary(library);

        // Then
        assertThat(created).isNotNull();
        assertThat(created.getId()).isPositive();
        assertThat(created.getName()).isEqualTo("Central Library");
        assertThat(created.getAddress()).isEqualTo("123 Main St");
        assertThat(created.getPhone()).isEqualTo("555-1234");
        assertThat(created.getEmail()).isEqualTo("central@library.com");
        assertThat(countRows("libraries")).isEqualTo(1);
    }

    @Test
    void createLibrary_withDuplicateEmail_shouldThrowException() {
        // Given
        libraryDAO.createLibrary(new Library("First Library", "Address 1", "111-1111", "duplicate@library.com"));
        Library library = new Library("Second Library", "Address 2", "222-2222", "duplicate@library.com");

        // When/Then
        assertThatThrownBy(() -> libraryDAO.createLibrary(library))
                .isInstanceOf(RuntimeException.class)
                .hasCauseInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void getLibraryById_whenExists_shouldReturnLibrary() {
        // Given
        Library created = libraryDAO.createLibrary(new Library("Test Library", "Test Address", "555-0000", "test@library.com"));

        // When
        Optional<Library> result = libraryDAO.getLibraryById(created.getId());

        // Then
        assertThat(result).isPresent();
        assertThat(result.get().getId()).isEqualTo(created.getId());
        assertThat(result.get().getName()).isEqualTo("Test Library");
        assertThat(result.get().getAddress()).isEqualTo("Test Address");
    }

    @Test
    void getLibraryById_whenNotExists_shouldReturnEmpty() {
        // When
        Optional<Library> result = libraryDAO.getLibraryById(999L);

        // Then
        assertThat(result).isEmpty();
    }

    @Test
    void findLibrariesByName_shouldReturnMatchingLibraries() {
        // Given
        libraryDAO.createLibrary(new Library("North Library", "North St", "111-1111", "north@lib.com"));
        libraryDAO.createLibrary(new Library("South Library", "South St", "222-2222", "south@lib.com"));
        libraryDAO.createLibrary(new Library("Northeast Branch", "NE St", "333-3333", "ne@lib.com"));

        // When
        List<Library> results = libraryDAO.findLibrariesByName("north");

        // Then
        assertThat(results).hasSize(2);
        assertThat(results).extracting(Library::getName)
                .containsExactlyInAnyOrder("North Library", "Northeast Branch");
    }

    @Test
    void findLibrariesByName_caseInsensitive_shouldReturnMatches() {
        // Given
        libraryDAO.createLibrary(new Library("Downtown Library", "Downtown", "555-5555", "downtown@lib.com"));

        // When
        List<Library> results = libraryDAO.findLibrariesByName("DOWNTOWN");

        // Then
        assertThat(results).hasSize(1);
        assertThat(results.get(0).getName()).isEqualTo("Downtown Library");
    }

    @Test
    void findLibrariesByName_noMatches_shouldReturnEmptyList() {
        // Given
        libraryDAO.createLibrary(new Library("Library A", "Address A", "111-1111", "a@lib.com"));

        // When
        List<Library> results = libraryDAO.findLibrariesByName("NonExistent");

        // Then
        assertThat(results).isEmpty();
    }

    @Test
    void getAllLibraries_shouldReturnAllLibrariesSortedByName() {
        // Given
        libraryDAO.createLibrary(new Library("Zebra Library", "Z St", "111-1111", "z@lib.com"));
        libraryDAO.createLibrary(new Library("Apple Library", "A St", "222-2222", "a@lib.com"));
        libraryDAO.createLibrary(new Library("Mango Library", "M St", "333-3333", "m@lib.com"));

        // When
        List<Library> results = libraryDAO.getAllLibraries();

        // Then
        assertThat(results).hasSize(3);
        assertThat(results).extracting(Library::getName)
                .containsExactly("Apple Library", "Mango Library", "Zebra Library");
    }

    @Test
    void getAllLibraries_whenEmpty_shouldReturnEmptyList() {
        // When
        List<Library> results = libraryDAO.getAllLibraries();

        // Then
        assertThat(results).isEmpty();
    }

    @Test
    void updateLibrary_shouldUpdateAllFields() {
        // Given
        Library created = libraryDAO.createLibrary(new Library("Old Name", "Old Address", "111-1111", "old@lib.com"));
        created.setName("New Name");
        created.setAddress("New Address");
        created.setPhone("999-9999");
        created.setEmail("new@lib.com");

        // When
        libraryDAO.updateLibrary(created);

        // Then
        Optional<Library> updated = libraryDAO.getLibraryById(created.getId());
        assertThat(updated).isPresent();
        assertThat(updated.get().getName()).isEqualTo("New Name");
        assertThat(updated.get().getAddress()).isEqualTo("New Address");
        assertThat(updated.get().getPhone()).isEqualTo("999-9999");
        assertThat(updated.get().getEmail()).isEqualTo("new@lib.com");
    }

    @Test
    void updateLibrary_withNonExistentId_shouldNotThrowException() {
        // Given
        Library library = new Library(999L, "Name", "Address", "111-1111", "email@lib.com");

        // When/Then
        assertThatCode(() -> libraryDAO.updateLibrary(library))
                .doesNotThrowAnyException();
    }

    @Test
    void deleteLibrary_byId_shouldRemoveLibrary() {
        // Given
        Library created = libraryDAO.createLibrary(new Library("To Delete", "Address", "111-1111", "delete@lib.com"));
        assertThat(countRows("libraries")).isEqualTo(1);

        // When
        libraryDAO.deleteLibrary(created.getId());

        // Then
        assertThat(countRows("libraries")).isZero();
        assertThat(libraryDAO.getLibraryById(created.getId())).isEmpty();
    }

    @Test
    void deleteLibrary_byObject_shouldRemoveLibrary() {
        // Given
        Library created = libraryDAO.createLibrary(new Library("To Delete", "Address", "111-1111", "delete@lib.com"));

        // When
        libraryDAO.deleteLibrary(created);

        // Then
        assertThat(countRows("libraries")).isZero();
    }

    @Test
    void deleteLibrary_nonExistent_shouldNotThrowException() {
        // When/Then
        assertThatCode(() -> libraryDAO.deleteLibrary(999L))
                .doesNotThrowAnyException();
    }
}