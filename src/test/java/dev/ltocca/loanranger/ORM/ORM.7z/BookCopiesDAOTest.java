// File: BookCopiesDAOTest.java
package dev.ltocca.loanranger.ORM;

import dev.ltocca.loanranger.domainModel.Book;
import dev.ltocca.loanranger.domainModel.BookCopy;
import dev.ltocca.loanranger.domainModel.Library;
import dev.ltocca.loanranger.domainModel.State.AvailableState;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

// Inherits: @JdbcTest, @Testcontainers, @Import, @Transactional, Container, Properties, Common DAOs, Constants, Helpers
class BookCopiesDAOTest extends OrmIntegrationTestBase {

    private Library testLibrary;
    private Book testBook;

    @BeforeEach
    void setUp() throws Exception { // Add throws Exception to handle the call to executeSchemaScript
        executeSchemaScript(); // Execute the schema script using the main DataSource before each test
        // Create a book specific to this test's context
        testBook = createTestBook(); // Uses helper from base class
        testLibrary = createTestLibrary(); // Uses helper from base class
    }

    @Test
    void createCopy_ShouldCreateBookCopySuccessfully() {
        // Arrange
        BookCopy bookCopy = new BookCopy(testBook, testLibrary, new AvailableState());

        // Act
        BookCopy createdCopy = bookCopiesDAO.createCopy(bookCopy);

        // Assert
        assertThat(createdCopy).isNotNull();
        assertThat(createdCopy.getCopyId()).isNotNull();
        assertThat(createdCopy.getBook().getIsbn()).isEqualTo(TEST_BOOK_ISBN);
        assertThat(createdCopy.getLibrary().getId()).isEqualTo(testLibrary.getId());
    }

    @Test
    void getCopyById_ShouldReturnBookCopyWhenExists() {
        // Arrange
        BookCopy bookCopy = createTestBookCopy(testBook, testLibrary); // Uses helper

        // Act
        Optional<BookCopy> foundCopy = bookCopiesDAO.getCopyById(bookCopy.getCopyId());

        // Assert
        assertThat(foundCopy).isPresent();
        assertThat(foundCopy.get().getCopyId()).isEqualTo(bookCopy.getCopyId());
        assertThat(foundCopy.get().getBook().getTitle()).isEqualTo(TEST_BOOK_TITLE);
    }

    @Test
    void getCopyById_ShouldReturnEmptyWhenBookCopyNotFound() {
        // Act
        Optional<BookCopy> foundCopy = bookCopiesDAO.getCopyById(999L);

        // Assert
        assertThat(foundCopy).isEmpty();
    }

    @Test
    void getAllBookCopies_ShouldReturnAllCopies() {
        // Arrange
        createTestBookCopy(testBook, testLibrary); // Uses helper
        Book book2 = new Book("978-0596009205", "Head First Design Patterns", "Eric Freeman");
        bookDAO.createBook(book2);
        createTestBookCopy(book2, testLibrary); // Uses helper

        // Act
        List<BookCopy> copies = bookCopiesDAO.getAllBookCopies();

        // Assert
        assertThat(copies).hasSize(2);
    }

    @Test
    void searchByTitle_ShouldReturnMatchingCopies() {
        // Arrange
        Book book2 = new Book("978-0596009205", "Effective Python", "Brett Slatkin");
        bookDAO.createBook(book2);

        createTestBookCopy(testBook, testLibrary); // "Effective Java"
        createTestBookCopy(book2, testLibrary); // "Effective Python"

        // Act
        List<BookCopy> foundCopies = bookCopiesDAO.searchByTitle("Effective");

        // Assert
        assertThat(foundCopies).hasSize(2);
    }
}